var $range = $(".js-range-slider"),
    $input = $(".js-input"),
    instance,
    min = 1000,
    max = 10000;
    step = 1000

$range.ionRangeSlider({
    skin: "big",
    type: "single",
    min: min,
    max: max,
    from: 0,
   
    onStart: function(data) {
        $input.prop("value", data.from);
    },
    onChange: function(data) {
        $input.prop("value", data.from);
    }
});

instance = $range.data("ionRangeSlider");

$input.on("change keyup", function() {
    var val = $(this).prop("value");

    // validate
    if (val < min) {
        val = min;
    } else if (val > max) {
        val = max;
    }

    instance.update({
        from: val
    });
});



// range slider for downpayement
function downpayment(){
    var $range = $(".js-range-sliderDownpayment"),
    $input = $(".js-inputDownpayment"),
    instance,
    min = 0,
    max = 100;
    step = 10

$range.ionRangeSlider({
    skin: "big",
    type: "single",
    min: min,
    max: max,
    from: 0,
   
    onStart: function(data) {
        $input.prop("value", data.from);
    },
    onChange: function(data) {
        $input.prop("value", data.from);
    }
});

instance = $range.data("ionRangeSlider");

$input.on("change keyup", function() {
    var val = $(this).prop("value");

    // validate
    if (val < min) {
        val = min;
    } else if (val > max) {
        val = max;
    }

    instance.update({
        from: val
    });
});

}

// range slider for Tenure
function TenureSlider(){
    var $range = $(".js-range-sliderTenure"),
    $input = $(".js-inputTenure"),
    instance,
    min = 12,
    max = 60;
    step = 10

$range.ionRangeSlider({
    skin: "big",
    type: "single",
    min: min,
    max: max,
    from: 0,
   
    onStart: function(data) {
        $input.prop("value", data.from);
    },
    onChange: function(data) {
        $input.prop("value", data.from);
    }
});

instance = $range.data("ionRangeSlider");

$input.on("change keyup", function() {
    var val = $(this).prop("value");

    // validate
    if (val < min) {
        val = min;
    } else if (val > max) {
        val = max;
    }

    instance.update({
        from: val
    });
});

}




$(document).ready(function(){
    downpayment()
    TenureSlider()
    $(document).on('input change', '.js-range-slider', function() { //listen to slider changes
        
          var v = $(this).val(); //getting slider val
          $('.js-input').html($(this).val());
          $(".js-range-slider").change(function() {
          var Value = $('.js-range-slider').val();
          $('.list-item').find('.carlist-box').filter(function () {
            if( $(this).attr('price') < Value){
                $(this).show()
                $(this).removeClass('disabled')
                $(this).addClass('range-available')
            }else if( $(this).attr('price') > Value){
                // $(this).hide()
                $(this).addClass('disabled')
                $(this).removeClass('range-available')
            }
          })



        //   $('.list-item').find('.carlist-box').filter(function () {
        //     return $(this).attr('price') > Value;
        //   }).hide()
        var carbox = $('.range-available').height()
        $('.disabled').height(carbox)
        });
         
        });

     
           // $(".trade-in-wrap").hide()
        $('.tradein-checkbox').change(function(){
            if($(this).is(':checked')){
                $(".trade-in-wrap").show()
            }else{
                $(".trade-in-wrap").hide()
            }
        })


        $('[data-toggle="collapse"]').on('click', function() {
            $navMenuCont = $($(this).data('target'));
            $navMenuCont.animate({
              'width': 'toggle'
            }, 350);
            $(".menu-overlay").fadeIn(500);
          
          });
          $(".menu-overlay").click(function(event) {
            $(".navbar-toggle").trigger("click");
            $(".menu-overlay").fadeOut(500);
          });
          
       
        //   compare checkbox

       
           
       
        // $('.car-link').click(function(){
           
        //     $('.checkboxcontainer').css("border", "5px solid #920023")
        //     $('.car-checkbox').prop('checked', true);
        //     $('.checkbox-wrapper').css("visibility","visible")
       
            
        // })

        // $('.car-link').click(function(){
        //     if (!$('.car-checkbox').is(':checked')) {
        //         $('.checkboxcontainer').css("border", "5px solid #920023")
        //         $('.car-checkbox').prop('checked', true);
        //         $('.checkbox-wrapper').css("visibility","visible")    
        //     }
        //     else {
        //         $('.checkboxcontainer').css("border", "none")
        //         $('.car-checkbox').prop('checked', false);
        //         $('.checkbox-wrapper').css("visibility","hidden") 
        //     }
        // })

        // $('.car-link').click(function(){
        //     if (!$(this).parents('.checkboxcontainer').find('.car-checkbox').is(':checked')) {
        //     $(this).parents('.checkboxcontainer').css("border", "5px solid #920023")
        //     $(this).parents('.checkboxcontainer').find('.car-checkbox').prop('checked', true);
        //     $(this).parents('.checkboxcontainer').find('.checkbox-wrapper').css("visibility","visible")
        //     }
        //     else{
        //     $(this).parents('.checkboxcontainer').css("border", "none")
        //     $(this).parents('.checkboxcontainer').find('.car-checkbox').prop('checked', false);
        //     $(this).parents('.checkboxcontainer').find('.checkbox-wrapper').css("visibility","hidden")
        //     }
        //     })


        $('.car-link').click(function(){
            var parent = $(this).parents('.checkboxcontainer')
            if (!parent.find('.car-checkbox').is(':checked')) {
            parent.css("border", "5px solid #c2082c")
            parent.find('.car-checkbox').prop('checked', true);
            parent.find('.checkbox-wrapper').css("visibility","visible")
            }
            else{
            parent.css("border", "none")
            parent.find('.car-checkbox').prop('checked', false);
            parent.find('.checkbox-wrapper').css("visibility","hidden")
            }
            })

            $('.bank-loans').click(function(){
                // $(this).css("border", "2px solid #c3002e")
                $(this).toggleClass('active-bank');
                // $('.active-bank').css("border", "2px solid #c3002e")
            })

            $('.radiocheck').click(function(){
               var rim = $('.radioinput').val()
               $('.addonprice').html(rim)
                var parent = $(this).parents('.radios')
                if(!parent.find('.radioinput').is(':checked')){
                    parent.css("border", "5px solid #c2082c", "border-radius","5px")
                    parent.find('.radioinput').prop('checked', true);
                    parent.toggleClass("collapsed radio-active");
                    parent.find('.radioinput').css('visibility', 'visible');
                    $('.starting-price-wrap').css('border-top','0')


                    // $('.ie .radioinput').css('display', 'none')
                    // $('.ie .radios').prepend('<img id="theImg" />')
                    // $('#theImg').css({
                    //     'margin-bottom': '0',
                    //     'width' : '25px',
                    //     'height' : '25px',
                    //     'position': 'absolute',
                    //     'bottom': '0'
                    //  });

                }
                else{
                    parent.removeClass("radio-active")
                    // parent.css("border", "1px solid #ccc")
                    parent.find('.radioinput').prop('checked', false);
                    parent.find('.radioinput').css('visibility', 'hidden');
                    $('.starting-price-wrap').css('border-top','1px solid #000')

                    // $('#theImg').css('display','none')
                }
               
            })


            // for internet explorer





               // for radio button
            //    $('.radiocheck').on('click', function(e) {
            //     $('.radios').toggleClass("collapsed radio-active"); //you can list several class names 
            //     e.preventDefault();
            //   });
            // $('.radiocheck').click(function(){
            //     var rim = $('.radioinput').val()
            //     $('.addonprice').html(rim)
            //     $('[name="rGroup"]').each(function() {
            //         var parent = $(this).parents('.radios')
            //         parent.css("border", "1px solid #ccc")
            //         parent.find('.radioinput').prop('checked', false);
            //         parent.find('.radioinput').css('visibility', 'hidden');
            //     })
            //     var parent = $(this).parents('.radios')
            //     parent.css("border", "5px solid #920023", "border-radius","5px")
            //     parent.find('.radioinput').prop('checked', true);
            //     parent.find('.radioinput').css('visibility', 'visible');
               
            // })


            // addon price
            
            $('#closemodal').click(function() {
                $('#modalwindow').modal('hide');
            });


            // for mobile header
            $('.navbar-toggler').on('click', function(e) {
                $('.navbar').toggleClass("collapsed menu-open"); //you can list several class names 
                e.preventDefault();
              });


            //   for logo heading change on tab change
          

            $('a[href="#compare"]').click(function(){
                // console.log('im in compare')
                $('.logo-beside-head').text('emi comparison calculator')
            })

            $('a[href="#bybudget"]').click(function(){
                // console.log('im in compare')
                $('.logo-beside-head').text('FINANCE CALCULATOR')
            })
            $('a[href="#bymodel"]').click(function(){
                // console.log('im in compare')
                $('.logo-beside-head').text('FINANCE CALCULATOR')
            })
            $('a[href="#byeligibility"]').click(function(){
                // console.log('im in compare')
                $('.logo-beside-head').text('FINANCE CALCULATOR')
            })






             /**
  * Detect OS & browsers
  */
 /* Add class for mac */
 if(navigator.appVersion.indexOf("Win")!=-1) {
    jQuery('body').addClass('window-os');
  }
  if(navigator.platform.toUpperCase().indexOf('MAC')>=0) {
    jQuery('body').addClass('mac-os');
  }
  if(navigator.appVersion.indexOf("Linux")!=-1) {
    jQuery('body').addClass('linux-os');
  }
  /* Add class for all ie version */
  var trident = !!navigator.userAgent.match(/Trident\/7.0/);
  var net = !!navigator.userAgent.match(/.NET4.0E/);
  var IE11 = trident && net;
  var IEold = ( navigator.userAgent.match(/MSIE/i) ? true : false );
  if(IE11 || IEold){
    jQuery('body').addClass('ie');
  }
  var ua = navigator.userAgent.toLowerCase();
  if (ua.indexOf('safari') != -1) {
    if (ua.indexOf('chrome') > -1) {
        jQuery('body').addClass('chrome');
    } else {
        jQuery('body').addClass('safari');
    }
  }
  var FF = !(window.mozInnerScreenX == null);
  if(FF) {
    jQuery('body').addClass('fire-fox');
  } else {
    //jQuery('body').addClass('not-fire-fox');
  }
  /* End os */
  
          

//   testing checkbox
$('.checkbox').click(function(){
    $('.checkbox').each(function(){
        $(this).prop('checked', false); 

        var c= $(this).parents('.opt')
        c.css({'border':'0', 'background': 'white'})
    }); 
    $(this).prop('checked', true);
   var c= $(this).parents('.opt')
   c.css('border','5px solid red')
});

})
var $range = $(".js-range-slider"),
    $input = $(".js-input"),
    instance,
    min = 1000,
    max = 10000;
    step = 1000

$range.ionRangeSlider({
    skin: "big",
    type: "single",
    min: min,
    max: max,
    from: 0,
   
    onStart: function(data) {
        $input.prop("value", data.from);
    },
    onChange: function(data) {
        $input.prop("value", data.from);
    }
});

instance = $range.data("ionRangeSlider");

$input.on("change keyup", function() {
    var val = $(this).prop("value");

    // validate
    if (val < min) {
        val = min;
    } else if (val > max) {
        val = max;
    }

    instance.update({
        from: val
    });
});


$(document).ready(function(){
    $(document).on('input change', '.js-range-slider', function() { //listen to slider changes
        
          var v = $(this).val(); //getting slider val
          $('.js-input').html($(this).val());
          $(".js-range-slider").change(function() {
          var Value = $('.js-range-slider').val();
          $('.list-item').find('.carlist-box').filter(function () {
            if( $(this).attr('price') < Value){
                $(this).show()
                $(this).removeClass('disabled')
                $(this).addClass('range-available')
            }else if( $(this).attr('price') > Value){
                // $(this).hide()
                $(this).addClass('disabled')
                $(this).removeClass('range-available')
            }
          })
        //   $('.list-item').find('.carlist-box').filter(function () {
        //     return $(this).attr('price') > Value;
        //   }).hide()
        var carbox = $('.range-available').height()
        $('.disabled').height(carbox)
        });
         
        });

     
           // $(".trade-in-wrap").hide()
        $('.tradein-checkbox').change(function(){
            if($(this).is(':checked')){
                $(".trade-in-wrap").show()
            }else{
                $(".trade-in-wrap").hide()
            }
        })


        $('[data-toggle="collapse"]').on('click', function() {
            $navMenuCont = $($(this).data('target'));
            $navMenuCont.animate({
              'width': 'toggle'
            }, 350);
            $(".menu-overlay").fadeIn(500);
          
          });
          $(".menu-overlay").click(function(event) {
            $(".navbar-toggle").trigger("click");
            $(".menu-overlay").fadeOut(500);
          });
          
       
        //   compare checkbox

       
           
       
        // $('.car-link').click(function(){
           
        //     $('.checkboxcontainer').css("border", "5px solid #920023")
        //     $('.car-checkbox').prop('checked', true);
        //     $('.checkbox-wrapper').css("visibility","visible")
       
            
        // })

        // $('.car-link').click(function(){
        //     if (!$('.car-checkbox').is(':checked')) {
        //         $('.checkboxcontainer').css("border", "5px solid #920023")
        //         $('.car-checkbox').prop('checked', true);
        //         $('.checkbox-wrapper').css("visibility","visible")    
        //     }
        //     else {
        //         $('.checkboxcontainer').css("border", "none")
        //         $('.car-checkbox').prop('checked', false);
        //         $('.checkbox-wrapper').css("visibility","hidden") 
        //     }
        // })

        // $('.car-link').click(function(){
        //     if (!$(this).parents('.checkboxcontainer').find('.car-checkbox').is(':checked')) {
        //     $(this).parents('.checkboxcontainer').css("border", "5px solid #920023")
        //     $(this).parents('.checkboxcontainer').find('.car-checkbox').prop('checked', true);
        //     $(this).parents('.checkboxcontainer').find('.checkbox-wrapper').css("visibility","visible")
        //     }
        //     else{
        //     $(this).parents('.checkboxcontainer').css("border", "none")
        //     $(this).parents('.checkboxcontainer').find('.car-checkbox').prop('checked', false);
        //     $(this).parents('.checkboxcontainer').find('.checkbox-wrapper').css("visibility","hidden")
        //     }
        //     })


        $('.car-link').click(function(){
            var parent = $(this).parents('.checkboxcontainer')
            if (!parent.find('.car-checkbox').is(':checked')) {
            parent.css("border", "5px solid #920023")
            parent.find('.car-checkbox').prop('checked', true);
            parent.find('.checkbox-wrapper').css("visibility","visible")
            }
            else{
            parent.css("border", "none")
            parent.find('.car-checkbox').prop('checked', false);
            parent.find('.checkbox-wrapper').css("visibility","hidden")
            }
            })

            $('.bank-loans').click(function(){
                $(this).css("border", "2px solid #c3002e")
            })

})